import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-SKWT5JZL.js";
import "./chunk-LEJOOHRV.js";
import "./chunk-6MAD7S5Y.js";
import "./chunk-4E4VHFF7.js";
import "./chunk-HOZOEZP5.js";
import "./chunk-YENVJQ5L.js";
import "./chunk-FRIKEHAD.js";
import "./chunk-HUWSEA2J.js";
import "./chunk-WI6LBH4V.js";
import "./chunk-BQTYKBYB.js";
import "./chunk-KDOJNZN6.js";
import "./chunk-HSNDBVJ3.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
