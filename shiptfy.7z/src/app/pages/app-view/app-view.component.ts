import { Component } from '@angular/core';

@Component({
  selector: 'app-app-view',
  standalone: true,
  imports: [],
  templateUrl: './app-view.component.html',
  styleUrl: './app-view.component.css'
})
export class AppViewComponent {

}
